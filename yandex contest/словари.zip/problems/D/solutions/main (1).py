N = int(input())
    

student_grades = {}
    
 
for _ in range(N):
        
    line = input().strip()
    name, grade = line.split()
        
    grade = float(grade)
        
        
    if name in student_grades:
        student_grades[name].append(grade)
    else:
            
        student_grades[name] = [grade]
    
    
student_name = input().strip()
    
    
grades = student_grades[student_name]
    
average_grade = sum(grades) / len(grades)
    
    
    
print(f"{average_grade:.2f}")

