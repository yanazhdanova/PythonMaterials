N = int(input())
    

grades_dict = {}
    

for _ in range(N):
       
    line = input().strip()
        
    name, grade = line.rsplit(maxsplit=1)
        
    grade = float(grade)
        
    grades_dict[name] = grade
    
    
total_grades = sum(grades_dict.values())
    
    
num_students = len(grades_dict)
    
    
average_grade = total_grades / num_students
    
    
print(f"{average_grade:.2f}")