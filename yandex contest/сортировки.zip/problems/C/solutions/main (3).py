def bubble_sort(arr):
    
    n = len(arr)
    
    
    for i in range(n - 1):
        
        swapped = False
        
      
        for j in range(n - i - 1):
           
            if arr[j] > arr[j + 1]:
                
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                
                swapped = True
        
        
        if not swapped:
            break
    
    return arr


n = int(input())


a = list(map(int, input().split()))


sorted_arr = bubble_sort(a)


print(" ".join(map(str, sorted_arr)))