def max_items_to_buy(prices, limit=10000):

    prices.sort()
    
     
    total_sum = 0
    item_count = 0
    
    
    for price in prices:
         
        if total_sum + price <= limit:
             
            total_sum += price
            item_count += 1
        else:
            
            break
    

    return item_count


N = int(input().strip())


prices = []
for _ in range(N):
    price = float(input().strip())
    prices.append(price)

    
result = max_items_to_buy(prices)
print(result)