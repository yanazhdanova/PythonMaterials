input_line = input()  
cards = list(map(int, input_line.split()))

for i in range(0, len(cards) - 1, 2):
    cards[i], cards[i + 1] = cards[i + 1], cards[i]
#print(" ".join(map(str, cards)))    
    # Этап 2: Меняем первую половину колоды со второй половиной
mid = len(cards) // 2
cards[:mid], cards[mid:] = cards[mid:], cards[:mid]
#print(" ".join(map(str, cards)))    
    # Этап 3: Меняем первую четверть колоды со второй четвертью
quarter = len(cards) // 4
cards[:quarter], cards[quarter:2 * quarter] = cards[quarter:2 * quarter], cards[:quarter]
#print(" ".join(map(str, cards)))    
    # Этап 4: Меняем третью четверть колоды со четвертой четвертью
cards[2 * quarter:3 * quarter], cards[3 * quarter:] = cards[3 * quarter:], cards[2 * quarter:3 * quarter]
    
    
print(" ".join(map(str, cards)))