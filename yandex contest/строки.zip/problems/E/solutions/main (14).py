input_line = input()  
cards = list(map(int, input_line.split()))

for i in range(0, len(cards) - 1, 2):
    cards[i], cards[i + 1] = cards[i + 1], cards[i]

mid = len(cards) // 2
cards[:mid], cards[mid:] = cards[mid:], cards[:mid]

quarter = len(cards) // 4
cards[:quarter], cards[quarter:2 * quarter] = cards[quarter:2 * quarter], cards[:quarter]

cards[2 * quarter:3 * quarter], cards[3 * quarter:] = cards[3 * quarter:], cards[2 * quarter:3 * quarter]
    
    
print(" ".join(map(str, cards)))