list1 = list(map(int, input().split()))

list2 = list(map(int, input().split()))
    
 
merged_list = []
    
    
for item1, item2 in zip(list1, list2):
        
    merged_list.append(item1)
      
    merged_list.append(item2)
        
   
if len(list1) > len(list2):
    merged_list.extend(list1[len(list2):])
    
elif len(list2) > len(list1):
    merged_list.extend(list2[len(list1):])
    
print(" ".join(map(str, merged_list)))