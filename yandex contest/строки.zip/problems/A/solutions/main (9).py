
input_line = input()
    

numbers = list(map(float, input_line.split()))

average = sum(numbers) / len(numbers)
numbers.sort()
    
n = len(numbers)
if n % 2 == 1:
        
    median = numbers[n // 2]
else:
    median = (numbers[n // 2 - 1] + numbers[n // 2]) / 2
    
   
print(f"{average:.2f} {median:.2f}")