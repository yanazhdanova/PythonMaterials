input_line = input().strip()
    
    
sequence = input_line.split()
    
if sequence == sequence[::-1]:
    print("yes")
else:
    print("no")