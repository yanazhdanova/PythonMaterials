input_line = input()
    
    
numbers = list(map(int, input_line.split()))
    
    
reversed_numbers = [-num for num in numbers[::-1]]
    
    
merged_list = numbers + reversed_numbers
    
    
print( " ".join(map(str, merged_list)))
    
    