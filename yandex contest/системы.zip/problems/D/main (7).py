
a = int(input())
if (a == 0):
     print (0)
else:
    b = bin(a)[2:]
    print(b.count('0'))
    