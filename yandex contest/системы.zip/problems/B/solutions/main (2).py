decimal_number = int(input())
    
    
print(bin(decimal_number)[2:])  
    
    
print( oct(decimal_number)[2:])
   
print(hex(decimal_number)[2:])