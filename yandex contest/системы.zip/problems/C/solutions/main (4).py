
input_line = input()
number, base = input_line.split()
base = int(base)

    
decimal_number = int(number, base)
    
   
def decimal_to_ternary(decimal):
    if decimal == 0:
        return '0'
        
    ternary_number = ''
    while decimal > 0:
        remainder = decimal % 3  
        ternary_number = str(remainder) + ternary_number
        decimal = decimal // 3  
        
    return ternary_number

    
ternary_number = decimal_to_ternary(decimal_number)

print(decimal_number, ternary_number)


