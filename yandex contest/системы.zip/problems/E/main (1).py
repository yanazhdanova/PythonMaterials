def sum_numbers():
    N = int(input())
    total_sum = 0  
    for _ in range(N):
        
        number, base = input().split()
        base = int(base)  
        
        
        decimal_value = int(number, base)
        
        
        total_sum += decimal_value

    
    print(total_sum)


sum_numbers()
