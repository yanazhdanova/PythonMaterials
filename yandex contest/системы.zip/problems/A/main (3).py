
    
number1, base1 = input().split()
base1 = int(base1)
    
    
number2, base2 = input().split()
base2 = int(base2)
    
    
decimal_number1 = int(number1, base1)
    
   
decimal_number2 = int(number2, base2)
    
   
if decimal_number1 < decimal_number2:
       
    print(bin(decimal_number1)[2:]) 
elif decimal_number1 > decimal_number2:
        
    print(bin(decimal_number2)[2:]) 
else:
        
    print("equal")


